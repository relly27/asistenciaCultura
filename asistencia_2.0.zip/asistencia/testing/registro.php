<?php
include 'conexion.php';
?>

<!DOCTYPE html>
<html>
<head>
	<title>Registro de asistencia</title>
</head>
<body>
	<h1>Registro de asistencia</h1>
	<form action="guardar_asistencia.php" method="post">
		<label>Nombre:</label>
		<input type="text" name="nombre"><br><br>
		<input type="submit" value="Registrar asistencia">
	</form>

	<?php
	$url = 'http://www.cne.gob.ve/web/registro_electoral/ce.php?nacionalidad=V&cedula=17092457';
$response = file_get_contents($url);
echo $response;


// Inicializar una sesión CURL
$ch = curl_init();

// Establecer la URL de la solicitud
curl_setopt($ch, CURLOPT_URL, 'http://www.cne.gob.ve/web/registro_electoral/ce.php?nacionalidad=V&cedula=27561321');

// Establecer el tipo de solicitud a GET
curl_setopt($ch, CURLOPT_HTTPGET, true);

// Ejecutar la solicitud y recibir la respuesta
$response = curl_exec($ch);

// Procesar la respuesta
if ($response === false) {
    // Error al ejecutar la solicitud
    echo 'Error: ' . curl_error($ch);
} else {
    // La solicitud se ejecutó correctamente
    echo 'Respuesta: ' . $response;
}

// Cerrar la sesión CURL
curl_close($ch);

?>

<!--<script>
	var xhr = new XMLHttpRequest();
xhr.open('GET', 'http://www.cne.gob.ve/web/registro_electoral/ce.php?nacionalidad=V&cedula=27561321', true);
xhr.onload = function() {
  if (this.status === 200) {
    var response = this.responseText;
    document.write(response);
  } else {
    console.error('Error en la solicitud.');
  }
};
xhr.send();
</script>-->

</body>
</html>
