<?php
	// Conexión a la base de datos
	//$conexion = mysqli_connect("localhost", "usuario", "contraseña", "basededatos");
	include 'conexion.php';

	// Obtener las asistencias registradas
	$query = "SELECT * FROM asistencias";
	$resultado = pg_query($conexion, $query);
	
	// Mostrar las asistencias en una tabla
	echo "<table border='1'>
			<tr>
				<th>ID</th>
				<th>Fecha</th>
				<th>Hora</th>
				<th>Nombre</th>
			</tr>";
	while($fila = pg_fetch_array($resultado)){
		echo "<tr>
				<td>".$fila["id"]."</td>
				<td>".$fila["fecha"]."</td>
				<td>".$fila["hora"]."</td>
				<td>".$fila["nombre"]."</td>
			</tr>";
	}
	echo "</table>";
?>
