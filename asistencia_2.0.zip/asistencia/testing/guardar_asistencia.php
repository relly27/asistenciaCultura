<?php
	// Conexión a la base de datos
	//$conexion = mysqli_connect("localhost", "usuario", "contraseña", "basededatos");
	include 'conexion.php';
	// Comprobar si el formulario ha sido enviado
	if(isset($_POST["nombre"])){
		// Obtener el nombre del empleado
		$nombre = $_POST["nombre"];
		$apellido = $_POST["apellido"];
		$cedula = $_POST["cedula"];
		
		// Obtener la fecha y hora actual
        date_default_timezone_set('America/caracas');
		$fecha = date('Y-m-d');
        $hora_actual = date('H:i:s');
        $hora = date('H:i:s');
		//$hora = date("H:i:s");
		
		// Insertar la asistencia en la base de datos
		$query = "INSERT INTO asistencias (fecha,hora,nombre,apellido,cedula) VALUES ('$fecha','$hora','$nombre','$apellido','$cedula')";
		pg_query($conexion, $query);
		
		// Mostrar un mensaje de confirmación
        if($query){
		echo "Asistencia registrada correctamente.";
        }else{ 
            echo 'no registrado';
        }
	}
?>
