<?php
include 'backend\cors.php'
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="assets\LOGO-GMC-VENEZUELA-(FULL-COLOR-FONDO-BLANCO).png">
    <link rel="stylesheet" href="css/style.css">
    <link href="node_modules/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet" type="text/css">
    <script src="lib\jquery-3.6.4.min.js"></script>
    <title>entradas</title>
</head>
<body>
    <?php include 'frontend/header.php' ?>

    <div class="logo">
        <img src="assets\LOGO-GMC-VENEZUELA-(FULL-COLOR-FONDO-BLANCO).png" class="img-fluid" alt="logo">
    </div>

   <div class="formu">

    <h1 class="h11 container">Registro de asistencia</h1>
    <p><h4>(si eres empleado solo coloca cedula)</h4></p>

	<form action="backend/guardar_asistencia.php" method="post" class="container">
            
        <div class="mb-3">
            <label class="form-label">nombre</label>
            <input type="text" class="form-control" name="nombre" placeholder="example : pedro">
            <div class="form-text">introduzca un nombre valido</div>
        </div>

        <div class="mb-3">
            <label class="form-label">apellido</label>
            <input type="text" class="form-control" name="apellido" placeholder="example : perez">
            <div class="form-text">introduzca un apellido valido</div>
        </div>

        <div class="mb-3">
            <label class="form-label">cedula[*]</label>
            <input type="number" class="form-control" name="cedula" placeholder="example : 23443582" required>
            <div class="form-text">introduzca una cedula valida</div>
        </div>
        
        <div class="mb-3">
            <label for="exampleFormControlTextarea1" class="form-label">Descripcion</label>
            <textarea class="form-control" id="exampleFormControlTextarea1" rows="3" placeholder="motivo de visita" name="descripcion"></textarea>
        </div>

        <input type="submit" class="btn btn-primary" value="registrar entrada"></input>

	</form>

    <div class="tableR">

    <a href="backend\consultar_asistencias.php">

        <button type="button" class="btn btn-primary">consultar entradas de visitantes</button>

    </a>

    </div>

    </div> 

    

    <footer class="footer">
    
    <small class="letras">&copy;2023 Todos los derechos reservados.</small>

</footer>

</body>


</html>