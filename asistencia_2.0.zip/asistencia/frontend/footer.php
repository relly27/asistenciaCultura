<footer class="footer">
    
    <small class="letras">&copy;2023 All rights reserved.</small>

</footer>
