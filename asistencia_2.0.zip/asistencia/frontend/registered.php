<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/style.css">
    <link rel="icon" href="..\assets\LOGO-GMC-VENEZUELA-(FULL-COLOR-FONDO-BLANCO).png">
    <link href="../node_modules/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet" type="text/css">
    <script src="lib\jquery-3.6.4.min.js"></script>
    <title>Document</title>
</head>
<body>

<header>

    <div>

        <img src="../assets/barra-efem(2).png" alt="baner" class="img-fluid">

    </div>


</header>

    <div class="msj">

        <div>

        <h1 style="text-align: center;" >usuario registrado correctamente</h1>

        </div>

        <br>

        <a href="../index.php">

            <button type="button" class="btn btn-primary">volver</button>

        </a>

    </div>

    <footer class="footer">
    
    <small class="letras">&copy;2023 All rights reserved.</small>

</footer>

</body>
</html>