<?php
include '../backend/cors.php';
// Conexión a la base de datos
$server = 'localhost';
$user = 'postgres';
$passw = '27561321';
$db = 'asistencias';

$conexion = pg_connect("host=$server user=$user password=$passw dbname=$db");

/*if($conexion){
    echo 'very good';
}else{
    echo 'not conect';
}*/


?>