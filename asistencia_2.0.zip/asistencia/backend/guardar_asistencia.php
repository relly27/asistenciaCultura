<?php
	// Conexión a la base de datos mysqli
	//$conexion = mysqli_connect("localhost", "usuario", "contraseña", "basededatos");
	include 'conexion.php';
	// Comprobar si el formulario ha sido enviado
	$id = $_POST["cedula"];
	$consulta = "SELECT nombre, cedula, apellido FROM nomina WHERE cedula = '$id'";
	$result = pg_query($conexion, $consulta);

	

	if(pg_num_rows($result) > 0){
		
		while ($row = pg_fetch_assoc($result)) {
			$nombre = $row['nombre'];
			$apellido = $row['apellido'];
			$cedula = $row['cedula'];
		
			$insertQuery = "INSERT INTO empleados (nombre, apellido, cedula) VALUES ('$nombre', '$apellido', '$cedula')";
			$insertResult = pg_query($conexion, $insertQuery);
		
			if (!$insertResult) {
				echo "Error al insertar los datos en la tabla 'empleados'.";
				exit;
			}
			if($insertQuery){
				header("Location: ../frontend/registered.php");
				die();
			}
		}

		 pg_close($conexion);

		

	}else{
		if (isset($_POST["nombre"]) && isset($_POST["apellido"]) && isset($_POST["cedula"])) {
			// Obtener los datos del formulario
			$nombre = $_POST["nombre"];
			$apellido = $_POST["apellido"];
			$cedula = $_POST["cedula"];
			$description = $_POST["descripcion"];
		
			// Verificar que los campos no estén vacíos
			if (!empty($nombre) && !empty($apellido) && !empty($cedula)) {
				// Obtener la fecha y hora actual
				date_default_timezone_set('America/Caracas');
				$fecha = date('Y-m-d');
				$hora = date('H:i:s');
		
				// Insertar los datos en la base de datos
				$query = "INSERT INTO visitantes (fecha, hora, nombre, apellido, cedula, descripcion) VALUES ('$fecha', '$hora', '$nombre', '$apellido', '$cedula', '$description')";
				$insertResult = pg_query($conexion, $query);
		
				// Verificar el resultado de la inserción
				if ($insertResult) {
					header("Location: ../frontend/registered.php");
					die();
				} else {
					echo "Error al registrar los datos.";
					die();
				}
			} else {
				echo "<h1>Por favor, completa todos los campos. usted no es empleado.</h1>";
				echo "<a href='../index.php'>volver a intentar</a>";
				die();
			}
		} else {
			echo "<h1>Por favor, completa todos los campos. usted no es empleado.</h1>";
			die();
		}
		
		// if(isset($_POST["nombre"]) && isset($_POST["apellido"]) && isset($_POST["cedula"])){
		// 	// Obtener el nombre del empleado
		// 	$nombre = $_POST["nombre"];
		// 	$apellido = $_POST["apellido"];
		// 	$cedula = $_POST["cedula"];
			
		// 	// Obtener la fecha y hora actual
		// 	date_default_timezone_set('America/caracas');
		// 	$fecha = date('Y-m-d');
		// 	$hora_actual = date('H:i:s');
		// 	$hora = date('H:i:s');
		// 	//$hora = date("H:i:s");
			
		// 	// Insertar la asistencia en la base de datos
		// 	$query = "INSERT INTO visitantes (fecha,hora,nombre,apellido,cedula) VALUES ('$fecha','$hora','$nombre','$apellido','$cedula')";
		// 	pg_query($conexion, $query);
			
		// 	// Mostrar un mensaje de confirmación
		// 	if($query){
		// 	header("Location: ../frontend/registered.php");
		// 	die();
		// 	pg_close($conexion);
			
		// 	}else{ 
		// 		echo 'no registrado';
		// 		die();
		// 		pg_close($conexion);
				
		// 	}
		// }
	}
?>
