<link href="../node_modules/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet" type="text/css">

<?php
	// Conexión a la base de datos
	//$conexion = mysqli_connect("localhost", "usuario", "contraseña", "basededatos");
	include 'conexion.php';

	// Obtener las asistencias registradas
	$query = "SELECT * FROM visitantes";
	$resultado = pg_query($conexion, $query);
	
	// Mostrar las asistencias en una tabla
	echo "<table class=\"table table-hover\">
			<tr class=\"table-primary\">
				<th>ID</th>
				<th>Nombre</th>
				<th>apellido</th>
				<th>cedula</th>
				<th>descripcion</th>
				<th>Fecha</th>
				<th>Hora</th>
			</tr>";
	while($fila = pg_fetch_array($resultado)){
		echo "<tr>
				<td>".$fila["id"]."</td>
				<td>".$fila["nombre"]."</td>
				<td>".$fila["apellido"]."</td>
				<td>".$fila["cedula"]."</td>
				<td>".$fila["descripcion"]."</td>
				<td>".$fila["fecha"]."</td>
				<td>".$fila["hora"]."</td>
			</tr>";
	}
	echo "</table>";
?>
